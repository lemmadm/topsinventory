<html>
    <head>    
    </head>
    <body>
        <h1>Inventory Management System</h1>
        <br>
        <h3>What is this repository for?</h3>
        <ul>
            <li>Inventory Management System for a Electonic Shop. </li>
            <li>version 1.0</li>
        </ul><br>
        <h3>How do I get set up?</h3>
        <ul>
            <li>Clone or Download the repository</li>
            <li>open the project</li>
            <li>Open the .env file and include your DB_USERNAME and DB_PASSWORD</li>
            <li>Copy the DB_DATABASE and make a new database in phpmyadmin with same name</li>
            <li>start the server</li>
            <li>migrate files using php artisan migrate</li>
            <li>run the project on your browser</li>
        </ul>
        <h3>Features</h3>
        <ul>
            <li>Google Sign In</li>
            <li>Catogory Selection</li>
            <li>Search For an Item</li>
            <li>Table Data Collection</li>
            <li>Admin and User Access</li>
            <li>Add item , Delete Item or UpdateItem features</li>
        </ul>
        <img src = "screenshots/Screenshot (75).png">
        <hr>
        <img src = "screenshots/Screenshot (76).png">
        <hr>
        <img src = "screenshots/Screenshot (77).png">
        <hr>
        <img src = "screenshots/Screenshot (78).png">
        <hr>
        <img src = "screenshots/Screenshot (79).png">
        
  <br><br>
        <h3>contact details</h3>
        <ul>
            <li>nuwan.harshamatrix@gmail.com</li>
            <li>erandanawijerathna@gmail.com</li>
            <li>sm201211d@gmail.com</li>
        </ul>
    </body>
</html>
