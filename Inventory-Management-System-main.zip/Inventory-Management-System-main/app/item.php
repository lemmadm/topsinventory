<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ITEM extends Model
{
    public $table = 'items';
}
