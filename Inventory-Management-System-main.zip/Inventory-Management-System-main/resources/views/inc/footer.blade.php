<div class="footer" style="position: fixed !important; left: 0 !important; bottom: 0 !important; width: 100% !important; background-color: black !important; color: white !important; text-align: center !important;">
    <p style="color:white">&copy;<script>document.write("-"+new Date().getFullYear());</script>- Faculty of Engineering - University of Peradeniya - All Rights Reserved</p>
</div>